#include "Clase.h"

Clase::Clase()
{
    //ctor
}
